To reset your password, follow the link below :
{{$str}}