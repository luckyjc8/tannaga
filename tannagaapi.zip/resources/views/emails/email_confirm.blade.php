Thank you for registering to Tannaga.

To activate your account, follow the link below :
{{$str}}