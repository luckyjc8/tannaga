Thank you for registering to Tannaga.

To activate your account, follow the link below :
<?php echo e($str); ?><?php /**PATH C:\laragon\www\tannagaapi\resources\views/emails/email_confirm.blade.php ENDPATH**/ ?>